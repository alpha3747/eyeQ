class AppImages {
  var appIcon = "assets/images/splash.png";
  var signuP_login_logo = "assets/images/Group 6356195.png";
  var otp = "assets/images/OTP security.png";
  var Homeicon = "assets/images/image2.png";
  var Selen = "assets/images/Selen.png";

  var Container_color = "assets/images/Container color.png";
  var Color_bliendness = "assets/images/Coorbliend.png";
  var AstigmatismImage = "assets/images/Astig.png";
  var RecoveryExercisesImage = "assets/images/Recovery.png";
  var ReportHistoryImage = "assets/images/Report.png";
  var eyetest = "assets/images/eye test.png";
  var Color_bliendness1 = "assets/images/color bilent.png";
  var sentelQuiz1 = "assets/images/image 3.png";
  var splash = "assets/images/applogo.png";

  var Excise1 = "assets/images/image 17.png";
  var plaming = "assets/images/plaming1.png";

  var near1 = "assets/images/near1.png";

  var c1 = "assets/images/1.png";

  var c2 = "assets/images/2.png";

  var c3 = "assets/images/3.png";

  var c4 = "assets/images/4.png";

  var c5 = "assets/images/5.png";

  var c6 = "assets/images/6.png";
  var c7 = "assets/images/7.png";
  var c8 = "assets/images/8.png";
  var c9 = "assets/images/9.png";
  var c10 = "assets/images/10.png";
  var c11 = "assets/images/11.png";
  var c12 = "assets/images/12.png";
  var c13 = "assets/images/13.png";
  var c14 = "assets/images/14.png";
  var c15 = "assets/images/15.png";
  var c16 = "assets/images/16.png";
  var c17 = "assets/images/17.png";
  var c18 = "assets/images/18.png";
  var c19 = "assets/images/19.png";
  var c20 = "assets/images/20.png";
}
